package com.neu.servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;

import javax.servlet.http.HttpServlet;
        import javax.servlet.http.HttpServletRequest;
        import javax.servlet.http.HttpServletResponse;
        import java.io.IOException;
/*
 *浏览器通过http可以访问每个Servlet.所以要给每个servlet定义一个映射请求也就是http访问的子目录
 *本Servlet访问的全路径是：http://localhost:8080/demo
 **/
@WebServlet("/demo") //ServletDemo的映射请求
public class ServletDemo extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //在get中执行doPost的方法
        doPost(req, resp);
    }
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //解决处理数据时的乱码问题
        //如果请求数据时乱码：后台从浏览器获取数据
        req.setCharacterEncoding("UTF-8");
        //响应式处理乱码：后台返回浏览器
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");
         //创建作用御,前台想要获取后台的数据，那么该数据一定要存储到作用御中
        req.setAttribute("hello","hello first servlet");
        //获取请求中的URI
        String uri=req.getRequestURI();
        System.out.println("请求是"+uri);
        //通过http的目录/demo访问ServletDemo.通过ServletDemo跳转到index.jsp: http://localhost；80
        req.getRequestDispatcher("index.jsp").forward(req,resp);
    }
}
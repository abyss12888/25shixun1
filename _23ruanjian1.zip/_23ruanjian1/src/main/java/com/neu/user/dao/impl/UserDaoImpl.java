package com.neu.user.dao.impl;

import com.neu.user.dao.UserDao;
import com.neu.user.entity.User;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDaoImpl implements UserDao {

    public User login(String uname, String upwd) {
        User user = null;
        //1.加载数据库驱动
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


        try {
            //2.创建数据库的连接"jdbc:mysql://localhost:3306/demo?serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true", "root", "123456"
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo?serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true", "root", "123456");
            //3.创建statement对象
            Statement st = conn.createStatement();
            // 定义sql语句
            String sql = "select * from user1 where uname='" + uname + "' and upwd='" + upwd + "'";
            //5.加载sql语句,将sql查询的数据返回结果集ResultSet
            ResultSet rs = st.executeQuery(sql);
            //6.从结果集中取出数据，然后给User类中的构造器赋值
            if (rs.next()) ;//next():从结果集中取数据，有返回true，没有返回false
            //给构造器中的形式赋值
            user = new User(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4));
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return user;
    }

    @Override
    public List<User> findUser() {
        List<User> list = new ArrayList<User>();
        //1.加载数据库的驱动
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            //2.创建数据库的连接
            Connection conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/demo?serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true",
                    "root", "123456");
            //3.创建Statement对象
            Statement st = conn.createStatement();
            //4.查询所有数据的sql语句
            String sql = "select * from user1";
            //加载sql语句，并返回结果
            ResultSet rs = st.executeQuery(sql);
            //循环结果集，获取每一条数据
            while (rs.next()) {
                //将取出的数据给构造器赋值
                User user = new User(rs.getInt(1), rs.getString(2), rs.getString(3)
                        , rs.getInt(4));
                //将创建每个对象存入集合
                list.add(user);
            }

        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }


    @Override
    public void delUser(int id) {
        //1.加载数据库驱动
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            //创建数据库连接
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo?serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true",
                    "root", "123456");
            //3.创建Statement对象
            Statement st = conn.createStatement();
            //4.写删除的sql语句
            String sql = "delete from user1 where id=" + id + "";
            //5.加载sql语句
            st.executeUpdate(sql);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public User findByUser(int id) {
        User user = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try {
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo?serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true",
                        "root", "123456");
                Statement st = conn.createStatement();
                String sql = "select * from user1 where id=" + id + "";

                ResultSet rs = st.executeQuery(sql);
                if (rs.next()) {
                    user = new User(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getInt(4));
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return user;
    }

    @Override
    public void updateUser(User user) throws ClassNotFoundException {
        //加载数据库驱动
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try {
                Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo?serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true",
                        "root", "123456");
                Statement st = conn.createStatement();
                //4. 与修改的sql
                String sql = "update user1 set uname='" + user.getUname() + "',upwd='" + user.getUpwd() + "',type='" + user.getType() + "' where id=" + user.getId() + "";
//5. 加载sql语句
                st.executeUpdate(sql);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
}
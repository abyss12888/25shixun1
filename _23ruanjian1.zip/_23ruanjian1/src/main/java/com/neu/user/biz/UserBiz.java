package com.neu.user.biz;

import com.neu.user.entity.User;

import java.util.List;

public interface UserBiz {
    //实现定义登录的方法
    public User login(String uname,String upwd) throws ClassNotFoundException;
    public List<User> findUser();
    public void delUser(int id);
    public User findByUser(int id);
    public void updateUser(User user);
}

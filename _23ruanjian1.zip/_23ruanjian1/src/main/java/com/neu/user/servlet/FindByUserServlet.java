package com.neu.user.servlet;

import com.neu.user.biz.UserBiz;
import com.neu.user.biz.impl.UserBizImpl;
import com.neu.user.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/findByUser")
public class FindByUserServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //处理字符编码
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");
        //获取前台传的id
        int id=Integer.parseInt(req.getParameter("id"));
        //创建UserBiz的对象
        UserBiz userBiz=new UserBizImpl();
        //调用方法
        User user=userBiz.findByUser(id);
        //将user存入作用域中
        req.setAttribute("user",user);
        //跳转到修改的页面
        req.getRequestDispatcher("updateUser.jsp").forward(req,resp);


    }
}
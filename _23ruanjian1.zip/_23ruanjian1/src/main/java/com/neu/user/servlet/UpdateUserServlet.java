package com.neu.user.servlet;

import com.neu.user.biz.UserBiz;
import com.neu.user.biz.impl.UserBizImpl;
import com.neu.user.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/updateUser")
public class UpdateUserServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //处理字符编码
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");
        //获取前台传递的参数
        int id=Integer.parseInt(req.getParameter("id"));
        String uname=req.getParameter("uname");
        String upwd=req.getParameter("upwd");
        int type=Integer.parseInt(req.getParameter("type"));
        //将修改之后的数据赋值给对象
        User user=new User(id,uname,upwd,type);
        //调用修改的方法
        UserBiz userBiz=new UserBizImpl();
        userBiz.updateUser(user);
        //修改完之后，要对数据库的数据重新查询，获取更新后的数据。所以跳转到/findUser的servlet
        req.getRequestDispatcher("/findUser").forward(req,resp);

    }
}
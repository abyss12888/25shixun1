package com.neu.user.servlet;


import com.neu.user.biz.UserBiz;
import com.neu.user.biz.impl.UserBizImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/delUser")
public class DelUserServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //处理字符编码
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");
        //获取前台传递的参数：http://localhost:8080/delUser?id=1
        String id=req.getParameter("id");
        //将id转换成int类型
        int ids=Integer.parseInt(id);
        //创建UserBiz的对象
        UserBiz userBiz=new UserBizImpl();
        //调用接口中删除的方法
        userBiz.delUser(ids);
        //删除数据后，重新查询数据库，获取最新的数据。跳转到findUser对应的servlet中
        req.getRequestDispatcher("/findUser").forward(req,resp);




    }
}
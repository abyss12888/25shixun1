package com.neu.user.servlet;

import com.neu.user.biz.UserBiz;
import com.neu.user.biz.impl.UserBizImpl;
import com.neu.user.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/findUser")
public class FindUserServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //处理字符编码
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");
        //创建UserBiz的对象，调用UserBiz中查询的方法
        UserBiz userBiz=new UserBizImpl();
        //调用查询的方法
        List<User> list= userBiz.findUser();
        //jsp如果想要获取后台数据，那么数据要存储到作用域中
        req.setAttribute("list",list);
        //跳转到findUser.jsp中
        req.getRequestDispatcher("findUser.jsp").forward(req,resp);

    }
}


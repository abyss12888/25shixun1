package com.neu.KefangLeixing.servlet;

import com.neu.KefangLeixing.biz.KefangLeixingBiz;
import com.neu.KefangLeixing.biz.impl.KefangLeixingBizImpl;
import com.neu.KefangLeixing.entity.KefangLeixing;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "UpdateKefangLeixingServlet", value = "/UpdateKefangLeixingServlet")
public class UpdateKefangLeixingServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        KefangLeixing kl = new KefangLeixing();
        kl.setId(Integer.parseInt(request.getParameter("id")));
        kl.setLeixingming(request.getParameter("leixingming"));
        kl.setEdingrenshu(Integer.parseInt(request.getParameter("edingrenshu")));
        kl.setBeizhu(request.getParameter("beizhu"));

        KefangLeixingBiz biz = new KefangLeixingBizImpl();
        biz.update(kl);

        response.sendRedirect("FindKefangLeixingServlet");
    }
}
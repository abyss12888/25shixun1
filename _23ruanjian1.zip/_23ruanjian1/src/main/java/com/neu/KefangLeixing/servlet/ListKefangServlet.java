package com.neu.KefangLeixing.servlet;

import com.neu.KefangLeixing.biz.impl.KefangLeixingBizImpl;
import com.neu.KefangLeixing.entity.KefangLeixing;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;


@WebServlet(name = "ListKefangServlet", value = "/listKefang")
public class ListKefangServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            KefangLeixingBizImpl biz = new KefangLeixingBizImpl();
            List<KefangLeixing> list = biz.findAll();
            request.setAttribute("list", list);
            request.getRequestDispatcher("/kefangleixing/list.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "数据库访问错误");
        }
    }
}
package com.neu.KefangLeixing.dao;


import com.neu.KefangLeixing.entity.KefangLeixing;

import java.util.List;

public interface KefangLeixingDao {
    boolean add(KefangLeixing kefangLeixing);
    boolean del(Integer id);
    boolean update(KefangLeixing kefangLeixing);
    List<KefangLeixing> findAll();
    KefangLeixing findById(Integer id);
}
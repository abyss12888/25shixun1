package com.neu.KefangLeixing.servlet;

import com.neu.KefangLeixing.biz.KefangLeixingBiz;
import com.neu.KefangLeixing.biz.impl.KefangLeixingBizImpl;
import com.neu.KefangLeixing.entity.KefangLeixing;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "FindKefangLeixingServlet", value = "/FindKefangLeixingServlet")
public class FindKefangLeixingServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        KefangLeixingBiz biz = new KefangLeixingBizImpl();
        List<KefangLeixing> list = biz.findAll();
        request.setAttribute("list", list);
        request.getRequestDispatcher("/kefangleixing/listKefang").forward(request, response);
    }
}
package com.neu.KefangLeixing.entity;

public class KefangLeixing {
    private Integer id;
    private String leixingming;
    private Integer edingrenshu;
    private String beizhu;

    public KefangLeixing() {}

    public KefangLeixing(Integer id, String leixingming, Integer edingrenshu, String beizhu) {
        this.id = id;
        this.leixingming = leixingming;
        this.edingrenshu = edingrenshu;
        this.beizhu = beizhu;
    }

    // Getters and Setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getLeixingming() { return leixingming; }
    public void setLeixingming(String leixingming) { this.leixingming = leixingming; }
    public Integer getEdingrenshu() { return edingrenshu; }
    public void setEdingrenshu(Integer edingrenshu) { this.edingrenshu = edingrenshu; }
    public String getBeizhu() { return beizhu; }
    public void setBeizhu(String beizhu) { this.beizhu = beizhu; }
}
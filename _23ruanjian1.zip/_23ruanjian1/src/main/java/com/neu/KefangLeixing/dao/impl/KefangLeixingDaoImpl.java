package com.neu.KefangLeixing.dao.impl;

import com.neu.KefangLeixing.dao.KefangLeixingDao;
import com.neu.KefangLeixing.entity.KefangLeixing;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class KefangLeixingDaoImpl implements KefangLeixingDao {

    // 数据库连接信息
    private static final String URL = "jdbc:mysql://localhost:3306/demo?serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "123456";

    @Override
    public boolean add(KefangLeixing kefangLeixing) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            String sql = "INSERT INTO kefangleixing(leixingming, edingrenshu, beizhu) VALUES(?,?,?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, kefangLeixing.getLeixingming());
            pstmt.setInt(2, kefangLeixing.getEdingrenshu());
            pstmt.setString(3, kefangLeixing.getBeizhu());
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            closeResources(conn, pstmt, null);
        }
    }

    @Override
    public boolean del(Integer id) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            String sql = "DELETE FROM kefangleixing WHERE id=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            closeResources(conn, pstmt, null);
        }
    }

    @Override
    public boolean update(KefangLeixing kefangLeixing) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            String sql = "UPDATE kefangleixing SET leixingming=?,edingrenshu=?,beizhu=? WHERE id=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, kefangLeixing.getLeixingming());
            pstmt.setInt(2, kefangLeixing.getEdingrenshu());
            pstmt.setString(3, kefangLeixing.getBeizhu());
            pstmt.setInt(4, kefangLeixing.getId());
            return pstmt.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            closeResources(conn, pstmt, null);
        }
    }

    @Override
    public List<KefangLeixing> findAll() {
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;
        List<KefangLeixing> list = new ArrayList<>();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            stmt = conn.createStatement();
            String sql = "SELECT * FROM kefangleixing";
            rs = stmt.executeQuery(sql);
            while(rs.next()) {
                KefangLeixing kl = new KefangLeixing(
                        rs.getInt("id"),
                        rs.getString("leixingming"),
                        rs.getInt("edingrenshu"),
                        rs.getString("beizhu")
                );
                list.add(kl);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeResources(conn, stmt, rs);
        }
        return list;
    }

    @Override
    public KefangLeixing findById(Integer id) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            String sql = "SELECT * FROM kefangleixing WHERE id=?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();
            if(rs.next()) {
                return new KefangLeixing(
                        rs.getInt("id"),
                        rs.getString("leixingming"),
                        rs.getInt("edingrenshu"),
                        rs.getString("beizhu")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            closeResources(conn, pstmt, rs);
        }
        return null;
    }

    // 关闭数据库资源的方法
    private void closeResources(Connection conn, Statement stmt, ResultSet rs) {
        try {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
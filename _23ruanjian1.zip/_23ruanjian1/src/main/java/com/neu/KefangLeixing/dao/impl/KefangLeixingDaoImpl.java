package com.neu.KefangLeixing.dao.impl;

import com.neu.KefangLeixing.dao.KefangLeixingDao;
import com.neu.KefangLeixing.entity.KefangLeixing;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;


public class KefangLeixingDaoImpl implements KefangLeixingDao {

    // 使用try-with-resources自动关闭连接
    @Override
    public boolean add(KefangLeixing kefangLeixing) {
        String sql = "INSERT INTO kefangleixing(leixingming, edingrenshu, beizhu) VALUES(?, ?, ?)";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, kefangLeixing.getLeixingming());
            pstmt.setInt(2, kefangLeixing.getEdingrenshu());
            pstmt.setString(3, kefangLeixing.getBeizhu());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean del(Integer id) {
        String sql = "DELETE FROM kefangleixing WHERE id=?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(KefangLeixing kefangLeixing) {
        String sql = "UPDATE kefangleixing SET leixingming=?, edingrenshu=?, beizhu=? WHERE id=?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, kefangLeixing.getLeixingming());
            pstmt.setInt(2, kefangLeixing.getEdingrenshu());
            pstmt.setString(3, kefangLeixing.getBeizhu());
            pstmt.setInt(4, kefangLeixing.getId());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<KefangLeixing> findAll() {
        List<KefangLeixing> list = new ArrayList<>();
        String sql = "SELECT * FROM kefangleixing";
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                KefangLeixing kl = new KefangLeixing(
                        rs.getInt("id"),
                        rs.getString("leixingming"),
                        rs.getInt("edingrenshu"),
                        rs.getString("beizhu")
                );
                list.add(kl);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public KefangLeixing findById(Integer id) {
        String sql = "SELECT * FROM kefangleixing WHERE id=?";
        try (Connection conn = getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    return new KefangLeixing(
                            rs.getInt("id"),
                            rs.getString("leixingming"),
                            rs.getInt("edingrenshu"),
                            rs.getString("beizhu")
                    );
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/demo?serverTimezone=UTC&useSSL=false",
                "root",
                "123456");
    }
}
package com.neu.KefangLeixing.biz;

import com.neu.KefangLeixing.entity.KefangLeixing;
import java.util.List;

public interface KefangLeixingBiz {
    boolean add(KefangLeixing kefangLeixing);
    boolean del(Integer id);
    boolean update(KefangLeixing kefangLeixing);
    List<KefangLeixing> findAll();
    KefangLeixing findById(Integer id);
}
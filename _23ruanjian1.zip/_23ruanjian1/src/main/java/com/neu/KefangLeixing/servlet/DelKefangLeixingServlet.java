package com.neu.KefangLeixing.servlet;

import com.neu.KefangLeixing.biz.KefangLeixingBiz;
import com.neu.KefangLeixing.biz.impl.KefangLeixingBizImpl;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "DelKefangLeixingServlet", value = "/DelKefangLeixingServlet")
public class DelKefangLeixingServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        KefangLeixingBiz biz = new KefangLeixingBizImpl();
        biz.del(id);

        response.sendRedirect("FindKefangLeixingServlet");
    }
}
package com.neu.KefangLeixing.biz.impl;

import com.neu.KefangLeixing.biz.KefangLeixingBiz;
import com.neu.KefangLeixing.dao.KefangLeixingDao;
import com.neu.KefangLeixing.dao.impl.KefangLeixingDaoImpl;
import com.neu.KefangLeixing.entity.KefangLeixing;

import java.util.List;

public class KefangLeixingBizImpl implements KefangLeixingBiz {
    // 创建KefangLeixingDao对象
    private KefangLeixingDao kefangLeixingDao = new KefangLeixingDaoImpl();

    @Override
    public boolean add(KefangLeixing kefangLeixing) {
        try {
            return kefangLeixingDao.add(kefangLeixing);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean del(Integer id) {
        try {
            return kefangLeixingDao.del(id);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean update(KefangLeixing kefangLeixing) {
        try {
            return kefangLeixingDao.update(kefangLeixing);
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public List<KefangLeixing> findAll() {
        try {
            return kefangLeixingDao.findAll();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public KefangLeixing findById(Integer id) {
        try {
            return kefangLeixingDao.findById(id);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
package com.neu.KefangLeixing.biz.impl;

import com.neu.KefangLeixing.biz.KefangLeixingBiz;
import com.neu.KefangLeixing.dao.KefangLeixingDao;
import com.neu.KefangLeixing.dao.impl.KefangLeixingDaoImpl;
import com.neu.KefangLeixing.entity.KefangLeixing;

import java.util.List;

public class KefangLeixingBizImpl implements KefangLeixingBiz {
    private KefangLeixingDao kefangLeixingDao = new KefangLeixingDaoImpl();

    @Override
    public boolean add(KefangLeixing kefangLeixing) {
        return kefangLeixingDao.add(kefangLeixing);
    }

    @Override
    public boolean del(Integer id) {
        return kefangLeixingDao.del(id);
    }

    @Override
    public boolean update(KefangLeixing kefangLeixing) {
        return kefangLeixingDao.update(kefangLeixing);
    }

    @Override
    public List<KefangLeixing> findAll() {
        return kefangLeixingDao.findAll();
    }

    @Override
    public KefangLeixing findById(Integer id) {
        return kefangLeixingDao.findById(id);
    }
}
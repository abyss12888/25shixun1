package com.neu.KefangLeixing.biz;

import com.neu.KefangLeixing.entity.KefangLeixing;
import java.util.List;

public interface KefangLeixingBiz {
    List<KefangLeixing> getAllKefangLeixing();
    KefangLeixing getKefangLeixingById(int id);
    boolean addKefangLeixing(KefangLeixing kefangLeixing);
    boolean updateKefangLeixing(KefangLeixing kefangLeixing);
    boolean deleteKefangLeixing(int id);
}

package com.neu.user.biz.impl;


import com.neu.user.biz.UserBiz;
import com.neu.user.dao.UserDao;
import com.neu.user.dao.impl.UserDaoImpl;
import com.neu.user.entity.User;

import java.util.List;

public class UserBizImpl implements UserBiz {
    //如果要调用UserDao的方法，要创建UserDao的对象
    private UserDao userDao = new UserDaoImpl();

    @Override
    public User login(String uname, String upwd) throws ClassNotFoundException {

        User user1 = userDao.login(uname, upwd);
        return user1;
    }

    @Override


    public List<User> findUser() {
        return userDao.findUser();
    }

    @Override
    public void delUser(int id) {
        userDao.delUser(id);
    }

    @Override
    public User findByUser(int id) {
        return userDao.findByUser(id);
    }

    @Override
    public void updateUser(User user) {
        try {
            userDao.updateUser(user);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }
}

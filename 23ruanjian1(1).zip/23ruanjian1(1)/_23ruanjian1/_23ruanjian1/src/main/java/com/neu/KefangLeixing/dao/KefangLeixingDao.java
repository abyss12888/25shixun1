package com.neu.KefangLeixing.dao;

import com.neu.KefangLeixing.entity.KefangLeixing;
import java.util.List;

public interface KefangLeixingDao {
    List<KefangLeixing> getAllKefangLeixing();
    KefangLeixing getKefangLeixingById(int id);
    boolean addKefangLeixing(KefangLeixing kefangLeixing);
    boolean updateKefangLeixing(KefangLeixing kefangLeixing);
    boolean deleteKefangLeixing(int id);
}

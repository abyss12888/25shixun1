package com.neu.KefangLeixing.dao.impl;

import com.neu.KefangLeixing.dao.KefangLeixingDao;
import com.neu.KefangLeixing.entity.KefangLeixing;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class KefangLeixingDaoImpl implements KefangLeixingDao {
    private static final String URL = "jdbc:mysql://localhost:3306/demo?serverTimezone=UTC&useSSL=false&allowPublicKeyRetrieval=true";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "123456";

    @Override
    public List<KefangLeixing> getAllKefangLeixing() {
        List<KefangLeixing> list = new ArrayList<>();
        String sql = "SELECT * FROM kefangleixing";
        try (Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                KefangLeixing kefangLeixing = new KefangLeixing(rs.getInt("id"), rs.getString("name"),
                        rs.getString("description"), rs.getDouble("price"));
                list.add(kefangLeixing);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public KefangLeixing getKefangLeixingById(int id) {
        String sql = "SELECT * FROM kefangleixing WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new KefangLeixing(rs.getInt("id"), rs.getString("name"),
                            rs.getString("description"), rs.getDouble("price"));
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean addKefangLeixing(KefangLeixing kefangLeixing) {
        String sql = "INSERT INTO kefangleixing (name, description, price) VALUES (?, ?, ?)";
        try (Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, kefangLeixing.getName());
            stmt.setString(2, kefangLeixing.getDescription());
            stmt.setDouble(3, kefangLeixing.getPrice());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean updateKefangLeixing(KefangLeixing kefangLeixing) {
        String sql = "UPDATE kefangleixing SET name = ?, description = ?, price = ? WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, kefangLeixing.getName());
            stmt.setString(2, kefangLeixing.getDescription());
            stmt.setDouble(3, kefangLeixing.getPrice());
            stmt.setInt(4, kefangLeixing.getId());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public boolean deleteKefangLeixing(int id) {
        String sql = "DELETE FROM kefangleixing WHERE id = ?";
        try (Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}


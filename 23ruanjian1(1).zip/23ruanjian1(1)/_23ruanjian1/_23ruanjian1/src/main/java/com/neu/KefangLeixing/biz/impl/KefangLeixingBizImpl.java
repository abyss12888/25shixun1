package com.neu.KefangLeixing.biz.impl;

import com.neu.KefangLeixing.biz.KefangLeixingBiz;
import com.neu.KefangLeixing.dao.KefangLeixingDao;
import com.neu.KefangLeixing.dao.impl.KefangLeixingDaoImpl;
import com.neu.KefangLeixing.entity.KefangLeixing;
import java.util.List;

public class KefangLeixingBizImpl implements KefangLeixingBiz {
    private KefangLeixingDao dao = new KefangLeixingDaoImpl();

    @Override
    public List<KefangLeixing> getAllKefangLeixing() {
        return dao.getAllKefangLeixing();
    }

    @Override
    public KefangLeixing getKefangLeixingById(int id) {
        return dao.getKefangLeixingById(id);
    }

    @Override
    public boolean addKefangLeixing(KefangLeixing kefangLeixing) {
        return dao.addKefangLeixing(kefangLeixing);
    }

    @Override
    public boolean updateKefangLeixing(KefangLeixing kefangLeixing) {
        return dao.updateKefangLeixing(kefangLeixing);
    }

    @Override
    public boolean deleteKefangLeixing(int id) {
        return dao.deleteKefangLeixing(id);
    }
}

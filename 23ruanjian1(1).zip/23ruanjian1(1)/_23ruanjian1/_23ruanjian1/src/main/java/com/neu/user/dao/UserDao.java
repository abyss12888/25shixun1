package com.neu.user.dao;

import com.neu.user.entity.User;

import java.util.List;

public interface UserDao {
    //根据用户名和密码登录
    public User login(String uname, String upwd);
    //查询所有的数据
    public List<User> findUser();
    //根据id删除数据
    public void  delUser(int id);
    //根据id查询数据
    public User findByUser(int id);
    //修改
    public  void  updateUser(User user) throws ClassNotFoundException;

}
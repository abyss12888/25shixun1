package com.neu.user.servlet;
import com.neu.user.biz.UserBiz;
import com.neu.user.biz.impl.UserBizImpl;
import com.neu.user.entity.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req,resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");
        //根据表单输入框的名字获取表单输入的值
        String uname=req.getParameter("uname");
        String upwd=req.getParameter("upwd");

        //从业务层中调用数据访问层的数据。要先创建一个业务层的接口对象
        UserBiz userBiz=new UserBizImpl();
        //调用登录的方法
        User user= null;
        try {
            user = userBiz.login(uname,upwd);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        if(user!=null){
            req.getRequestDispatcher("index.jsp").forward(req,resp);
        }else{
            //重定向到登楼页面
            resp.sendRedirect("login.jsp");

        }
    }
}


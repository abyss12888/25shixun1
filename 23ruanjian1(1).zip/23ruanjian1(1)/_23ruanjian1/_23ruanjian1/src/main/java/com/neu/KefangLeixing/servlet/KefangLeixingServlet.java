package com.neu.KefangLeixing.servlet;

import com.neu.KefangLeixing.biz.KefangLeixingBiz;
import com.neu.KefangLeixing.biz.impl.KefangLeixingBizImpl;
import com.neu.KefangLeixing.entity.KefangLeixing;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet("/KefangLeixingServlet")
public class KefangLeixingServlet extends HttpServlet {

    private KefangLeixingBiz biz = new KefangLeixingBizImpl();

    // 展示所有房间类型
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<KefangLeixing> list = biz.getAllKefangLeixing();
        request.setAttribute("kefangLeixingList", list);
        request.getRequestDispatcher("/WEB-INF/kefangleixing/list.jsp").forward(request, response);
    }

    // 根据ID查询房间类型
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        KefangLeixing kefangLeixing = biz.getKefangLeixingById(id);
        request.setAttribute("kefangLeixing", kefangLeixing);
        request.getRequestDispatcher("/WEB-INF/kefangleixing/detail.jsp").forward(request, response);
    }
}
